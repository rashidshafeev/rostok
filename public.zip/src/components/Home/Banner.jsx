import BannerOne from './TypesOfBanner/BannerOne';

const Banner = () => {
  return (
    <div className='mt-5 slider'>
      <BannerOne />
    </div>
  );
};

export default Banner;
