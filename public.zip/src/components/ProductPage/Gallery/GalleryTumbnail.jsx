import React from 'react'

function GalleryTumbnail() {
  return (
    <div>GalleryTumbnail</div>
  )
}

export default GalleryTumbnail