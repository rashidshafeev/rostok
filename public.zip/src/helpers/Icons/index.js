import { ArrowIcon } from './ArrowIcon';
import FavoriteIcon from './FavoriteIcon';
import ComparisonIcon from './ComparisonIcon';
import { DeleteIcon } from './DeleteIcon';

export { ArrowIcon, FavoriteIcon, ComparisonIcon, DeleteIcon };
