import React from 'react'

function AddressBar() {
  return (
    <div>AddressBar</div>
  )
}

export default AddressBar