import { SRMain } from '../../components';

const SearchResults = () => {
  return <SRMain />;
};

export default SearchResults;
